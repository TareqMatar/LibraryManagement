-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.1.29-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win32
-- HeidiSQL Version:             10.1.0.5505
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for librarymanagement
CREATE DATABASE IF NOT EXISTS `librarymanagement` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;
USE `librarymanagement`;

-- Dumping structure for table librarymanagement.author
CREATE TABLE IF NOT EXISTS `author` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table librarymanagement.author: ~2 rows (approximately)
/*!40000 ALTER TABLE `author` DISABLE KEYS */;
INSERT INTO `author` (`id`, `name`, `address`, `phone`) VALUES
	(1, 'Ali', 'Gaza', 123456789),
	(3, 'Ahmed', 'Jordan', 124587658);
/*!40000 ALTER TABLE `author` ENABLE KEYS */;

-- Dumping structure for table librarymanagement.books
CREATE TABLE IF NOT EXISTS `books` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `category` int(11) NOT NULL,
  `author` int(11) NOT NULL,
  `description` text CHARACTER SET utf8,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table librarymanagement.books: ~2 rows (approximately)
/*!40000 ALTER TABLE `books` DISABLE KEYS */;
INSERT INTO `books` (`id`, `name`, `category`, `author`, `description`) VALUES
	(1, 'PHPCode', 2, 3, 'php code learn'),
	(2, 'JAVA', 1, 1, 'java code');
/*!40000 ALTER TABLE `books` ENABLE KEYS */;

-- Dumping structure for table librarymanagement.borrowerbooks
CREATE TABLE IF NOT EXISTS `borrowerbooks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `borrower_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `borrower_date` date NOT NULL,
  `return_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table librarymanagement.borrowerbooks: ~2 rows (approximately)
/*!40000 ALTER TABLE `borrowerbooks` DISABLE KEYS */;
INSERT INTO `borrowerbooks` (`id`, `borrower_id`, `book_id`, `borrower_date`, `return_date`) VALUES
	(1, 3, 2, '2020-05-18', '2020-05-19'),
	(2, 2, 1, '2020-05-17', '2020-05-20');
/*!40000 ALTER TABLE `borrowerbooks` ENABLE KEYS */;

-- Dumping structure for table librarymanagement.borrowers
CREATE TABLE IF NOT EXISTS `borrowers` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `firstName` varchar(255) CHARACTER SET utf8 NOT NULL,
  `lastName` varchar(255) CHARACTER SET utf8 NOT NULL,
  `phone` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `gender` tinytext CHARACTER SET utf8,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table librarymanagement.borrowers: ~4 rows (approximately)
/*!40000 ALTER TABLE `borrowers` DISABLE KEYS */;
INSERT INTO `borrowers` (`id`, `firstName`, `lastName`, `phone`, `email`, `address`, `gender`) VALUES
	(1, 'omar', 'khaled', 'Male', '123547854', 'Gaza', 'oo@o.com'),
	(2, 'Adnan', 'Adel', 'Male', '12458798', 'Hebron', 'aa@a.com'),
	(3, 'hussien', 'naser', 'Male', '225487586', 'Khalil', 'hh@h.com'),
	(5, 'test', 'test', 'Male', '1234567898', 'test', 'test@tt.com');
/*!40000 ALTER TABLE `borrowers` ENABLE KEYS */;

-- Dumping structure for table librarymanagement.category
CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `catname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table librarymanagement.category: ~2 rows (approximately)
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` (`id`, `catname`, `status`) VALUES
	(1, 'Java', 'Active'),
	(2, 'phpLaravel', 'DeActive');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;

-- Dumping structure for table librarymanagement.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `password` varchar(255) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table librarymanagement.users: ~2 rows (approximately)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `name`, `password`) VALUES
	(1, 'tareq', '123'),
	(2, 'ali', '123456');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
